﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2HargunpalSinghP2
{
    class Program
    {
        static float volume(float r)
        {
            float pi = 3.14159f;
            float sp = (4 / 3) * pi * r * r * r;
            return sp;
        }
        static float volume(float r, float h)
        {
            float pi = 3.14159f;
            float cy = pi * r * r * h;
            return cy;
        }
        static float volume(float l, float w, float h)
        {
            float rp = l * w * h;
            return rp;
        }

        int q;

        static void Main(string[] args)
        {
            Console.WriteLine("Kindly enter a specefic number to opt for a shape");
            Console.WriteLine("1 for sphere");
            Console.WriteLine("2 for  cylinder");
            Console.WriteLine("3 for  rectangular prism ");
            string call=Console.ReadLine();
            int q = int.Parse(call);

            if (q == 1)
            {
                Console.WriteLine("Kindly enter a value for radius.");
                string R =Console.ReadLine();
                float r = float.Parse(R);
                float x = volume(r);

                Console.WriteLine("The volume of sphere with radius "+r+" is "+x);
            }

            else if (q == 2)
            {
                Console.WriteLine("Kindly enter a value for radius.");
                string R = Console.ReadLine();
                float r = float.Parse(R);

                Console.WriteLine("and now enter a value for height.");
                string H = Console.ReadLine();
                float h = float.Parse(H);
                float y = volume(r, h);

                Console.WriteLine("The Volume of cylinder with  radius "+r+" and height "+h+" is " + y);
            } 

            else if (q == 3)
            {
                Console.WriteLine("Kindly enter a value for lenght.");
                string L = Console.ReadLine();
                float l = float.Parse(L);

                Console.WriteLine("now enter a value for width.");
                string W = Console.ReadLine();
                float w = float.Parse(W);

                Console.WriteLine("You are just left with height to enter.");
                string H = Console.ReadLine();
                float h = float.Parse(H);

                float z = volume(l, w, h);

                Console.WriteLine("The Volume of rectangular prism with length "+ l +" , breadth "+ w + " and height " + h + " is " + z);
            }


        }
    }
}
