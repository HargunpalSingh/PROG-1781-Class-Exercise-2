﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2HargunpalSinghP1
{
    class Program
    {
        static float hst(int amount, int tax)
        {
            float finalfees = amount * (tax / 100);
            return finalfees;

        }
        
        static void Main(string[] args)
        {
            Console.WriteLine("Kindly mention wether you are a Canadian Citizen or an International Student");
            Console.WriteLine("Press c: if you are a Canadian Citizen");
            Console.WriteLine("Press i: if you are an international student");
            
            string q = Console.ReadLine();
            
            Console.WriteLine("Also tell your age here");
            string age = Console.ReadLine();
            int a = int.Parse(age);

            int baseamount , intercharges;
            int tax = 13;
            string internationalstd;


            if (q == "c")
            {
                if (a <= 18)
                {
                    internationalstd="NO";
                    intercharges = 0;
                    baseamount = 300;

                }
                else if (a <= 49)

                {
                    internationalstd = "NO";
                    intercharges = 0;
                    baseamount = 500;

                }

                else
                    
                 {
                    internationalstd = "NO";
                    intercharges =0;
                    baseamount = 400;

                }

            }

            else
            {
                if (a <= 18)
                {

                    internationalstd = "YES";
                    intercharges = 100;
                    baseamount = 300;

                }
                else if (a <= 49)

                {
                    internationalstd = "YES";
                    intercharges = 100;
                    baseamount = 500;

                }

                else
                    
                 {
                    internationalstd = "YES";
                    intercharges = 100;
                    baseamount = 400;

                }

            }

            int primaryfees = baseamount + intercharges;

            Console.WriteLine("Kindly enter a specefic number for the month of your registraion");
            string MON = Console.ReadLine();
            int mon = int.Parse(MON);

            int regmon;


            switch (mon)
            {
                case 1:
                    {
                        regmon = 220;
                        break;
                    }

                case 2:
                    {
                        regmon = 220;
                        break;
                    }
                case 3:
                    {
                        regmon = 220;
                        break;
                    }
                case 4:
                    {
                        regmon = 220;
                        break;
                    }

                case 5:
                    {
                        regmon = 150;
                        break;
                    }

                case 6:
                    {
                        regmon = 150;
                        break;
                    }
                case 7:
                    {
                        regmon = 150;
                        break;
                    }
                case 8:
                    {
                        regmon = 150;
                        break;
                    }

                case 9:
                    {
                        regmon = 250;
                        break;
                    }

                case 10:
                    {
                        regmon = 250;
                        break;
                    }

                case 11:
                    {
                        regmon = 250;
                        break;
                    }

                case 12:
                    {
                        regmon = 250;
                        break;
                    }

                default:

                    {
                        regmon = 0;
                        break;

                    }
            }


            int finalfees = primaryfees + regmon;
            float taxes = hst(finalfees, tax);
            float finaltotal = taxes = finalfees;


            Console.WriteLine("The Student's age: "+a);
            Console.WriteLine("International Student: "+ internationalstd);
            Console.WriteLine("Registration Semester: "+mon);

            Console.WriteLine("Base Tuition: "+baseamount);
            Console.WriteLine("International Student fee: "+intercharges);
            Console.WriteLine("Registration Fee for semester: "+regmon);
            Console.WriteLine("HST: "+taxes);
            Console.WriteLine("Final Total: " + finaltotal);


        }
    }
}
